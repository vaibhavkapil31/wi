const express = require("express");
const port = 9000;
const app = express();
const bodyParser = require("body-parser");

var todos = [
  { id: 1, title: "AGENT X JOB 1" },
  { id: 2, title: "AGENT X JOB 2" },
  { id: 3, title: "AGENT X JOB 3" },
];

app.use(bodyParser.json());

app.get("/", (request, response) => response.status(200).json(todos));

app.post("/", (request, response) => {
  var newTodo = JSON.parse(request.body);
  newTodo.id = todos.length + 1;
  todos.push(newTodo);
  response.status(201).json();
});

app.put("/:id", (request, response) => {
  var id = 1;
  if (todos[id - 1]) {
    todos[id - 1] = request.body;
    response.status(204).send();
  } else {
    response.status(404, "The task is not found").send();
  }
});

app.listen(port);
